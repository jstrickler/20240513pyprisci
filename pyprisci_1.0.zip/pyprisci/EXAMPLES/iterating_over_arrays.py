
my_list = ["Idle", "Cleese", "Chapman", "Gilliam", "Palin", "Jones"]
my_tuple = "Roger", "Old Woman", "Prince Herbert", "Brother Maynard"
my_str = "She turned me into a newt"

for p in my_list:  # Iterate over elements of list
    print(p)
print()

for r in my_tuple:  # Iterate over elements of tuple
    print(r)
print()

for ch in my_str:  # Iterate over characters of string
    print(ch, end=' ')
print()
