
for i in range(0x1F300, 0x1f538):
    print(chr(i), end=' ')
print()


