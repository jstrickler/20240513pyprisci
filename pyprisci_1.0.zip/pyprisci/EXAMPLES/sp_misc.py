import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import pandas as pd


def main():
    pass  # code here


if __name__ == '__main__':
    main()
