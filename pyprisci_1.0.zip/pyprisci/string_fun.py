name = "john jacob jingleheimer schmidt"

# put your Python code here:

